# Williams Facebook Lister License Bot

## Setup
1. Install Node.js 20+
2. Run `npm install`
3. Copy `.env.example` to `.env`
4. Fill in DISCORD_TOKEN, CLIENT_ID, GUILD_ID
5. Run `npm start`

## Discord Commands
- `/key-create duration:30d user:@person`
- `/key-create duration:lifetime user:@person`
- `/key-revoke key:WFL-XXXX-XXXX`
- `/key-info key:WFL-XXXX-XXXX`
- `/key-list`

## Extension validation endpoint
POST `/validate`
```json
{"key":"WFL-XXXX-XXXX","fingerprint":"browser-or-device-id"}
```
