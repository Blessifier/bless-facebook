require('dotenv').config();
const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const db = new Database('licenses.db');
db.exec(`CREATE TABLE IF NOT EXISTS licenses (
  key TEXT PRIMARY KEY,
  owner_id TEXT,
  owner_tag TEXT,
  created_by TEXT,
  created_at INTEGER,
  expires_at INTEGER,
  revoked INTEGER DEFAULT 0,
  notes TEXT
);`);
db.exec(`CREATE TABLE IF NOT EXISTS activations (
  key TEXT,
  fingerprint TEXT,
  last_seen INTEGER,
  PRIMARY KEY(key, fingerprint)
);`);

function makeKey() {
  return 'WFL-' + crypto.randomBytes(12).toString('hex').toUpperCase().match(/.{1,4}/g).join('-');
}
function parseDuration(str) {
  if (!str) return null;
  if (str.toLowerCase() === 'lifetime') return 0;
  const m = str.match(/^(\d+)(m|h|d|w|mo|y)$/i);
  if (!m) throw new Error('Use duration like 1d, 7d, 30d, 1mo, 1y, or lifetime');
  const n = Number(m[1]);
  const unit = m[2].toLowerCase();
  const mult = {m:60000,h:3600000,d:86400000,w:604800000,mo:2592000000,y:31536000000}[unit];
  return Date.now() + n * mult;
}
function checkKey(key, fingerprint='unknown') {
  const row = db.prepare('SELECT * FROM licenses WHERE key=?').get(key);
  if (!row) return { valid:false, reason:'invalid_key' };
  if (row.revoked) return { valid:false, reason:'revoked' };
  if (row.expires_at && Date.now() > row.expires_at) return { valid:false, reason:'expired' };
  db.prepare('INSERT OR REPLACE INTO activations(key,fingerprint,last_seen) VALUES(?,?,?)').run(key, fingerprint, Date.now());
  return { valid:true, expires_at: row.expires_at || 'lifetime', owner_id: row.owner_id || null };
}

const app = express();
app.use(cors());
app.use(express.json());
app.post('/validate', (req,res) => {
  const { key, fingerprint } = req.body || {};
  if (!key) return res.status(400).json({ valid:false, reason:'missing_key' });
  res.json(checkKey(String(key).trim(), String(fingerprint || 'unknown')));
});
app.get('/health', (_,res)=>res.json({ ok:true }));
app.listen(process.env.PORT || 3000, () => console.log('License API running'));

const commands = [
  new SlashCommandBuilder().setName('key-create').setDescription('Create a Williams Facebook Lister license key')
    .addStringOption(o=>o.setName('duration').setDescription('1d, 7d, 30d, 1mo, 1y, lifetime').setRequired(true))
    .addUserOption(o=>o.setName('user').setDescription('User this key is for').setRequired(false))
    .addStringOption(o=>o.setName('notes').setDescription('Optional notes').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('key-revoke').setDescription('Revoke a license key')
    .addStringOption(o=>o.setName('key').setDescription('License key').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('key-info').setDescription('Show key info')
    .addStringOption(o=>o.setName('key').setDescription('License key').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('key-list').setDescription('List recent license keys')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
].map(c=>c.toJSON());

async function registerCommands() {
  const rest = new REST({ version:'10' }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands });
  console.log('Discord commands registered');
}

const client = new Client({ intents:[GatewayIntentBits.Guilds] });
client.on('interactionCreate', async i => {
  if (!i.isChatInputCommand()) return;
  try {
    if (process.env.ADMIN_ROLE_ID && !i.member.roles.cache.has(process.env.ADMIN_ROLE_ID)) {
      return i.reply({ content:'You do not have permission to use this.', ephemeral:true });
    }
    if (i.commandName === 'key-create') {
      const duration = i.options.getString('duration');
      const user = i.options.getUser('user');
      const notes = i.options.getString('notes') || '';
      const key = makeKey();
      const expires = parseDuration(duration);
      db.prepare('INSERT INTO licenses(key,owner_id,owner_tag,created_by,created_at,expires_at,notes) VALUES(?,?,?,?,?,?,?)')
        .run(key, user?.id || null, user?.tag || null, i.user.tag, Date.now(), expires, notes);
      return i.reply({ content:`Created key:\n\`${key}\`\nExpires: ${expires === 0 ? 'Lifetime' : new Date(expires).toLocaleString()}`, ephemeral:true });
    }
    if (i.commandName === 'key-revoke') {
      const key = i.options.getString('key').trim();
      db.prepare('UPDATE licenses SET revoked=1 WHERE key=?').run(key);
      return i.reply({ content:`Revoked: \`${key}\``, ephemeral:true });
    }
    if (i.commandName === 'key-info') {
      const key = i.options.getString('key').trim();
      const row = db.prepare('SELECT * FROM licenses WHERE key=?').get(key);
      if (!row) return i.reply({ content:'Key not found.', ephemeral:true });
      const acts = db.prepare('SELECT COUNT(*) as n FROM activations WHERE key=?').get(key).n;
      return i.reply({ content:`Key: \`${row.key}\`\nOwner: ${row.owner_tag || 'None'}\nExpires: ${row.expires_at ? new Date(row.expires_at).toLocaleString() : 'Lifetime'}\nRevoked: ${row.revoked ? 'Yes' : 'No'}\nDevices: ${acts}`, ephemeral:true });
    }
    if (i.commandName === 'key-list') {
      const rows = db.prepare('SELECT * FROM licenses ORDER BY created_at DESC LIMIT 10').all();
      return i.reply({ content: rows.map(r=>`\`${r.key}\` — ${r.owner_tag || 'No owner'} — ${r.expires_at ? new Date(r.expires_at).toLocaleDateString() : 'Lifetime'}${r.revoked ? ' — REVOKED' : ''}`).join('\n') || 'No keys yet.', ephemeral:true });
    }
  } catch (e) { return i.reply({ content:'Error: ' + e.message, ephemeral:true }); }
});

if (!process.env.DISCORD_TOKEN) console.log('Missing DISCORD_TOKEN in .env');
else registerCommands().then(()=>client.login(process.env.DISCORD_TOKEN));
